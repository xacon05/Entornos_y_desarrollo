import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import sample.Utils;

/**
 * Pruebas unitarias para la clase Utils.
 */
public class UtilsJUnit4Test {

    public UtilsJUnit4Test() {
    }

    @BeforeClass
    public static void setUpClass() {
        System.out.println("Iniciando pruebas en UtilsJUnit4Test...");
    }

    @AfterClass
    public static void tearDownClass() {
        System.out.println("Finalizando pruebas en UtilsJUnit4Test...");
    }

    /**
     * Prueba simple del método concatWords.
     */
    @Test
    public void testHelloWorld() {
        System.out.println("* UtilsJUnit4Test: test method 1 - testHelloWorld()");
        assertEquals("Hello, world!", Utils.concatWords("Hello", ", ", "world", "!"));
    }

    /**
     * Prueba del método concatWords con entrada nula.
     */
    @Test
    public void testConcatWords() {
        System.out.println("* UtilsJUnit4Test: testConcatWords()");
        String[] words = null;
        String expResult = "";
        String result = Utils.concatWords(words);
        assertEquals(expResult, result);
    }

    /**
     * Prueba con tiempo límite para computeFactorial.
     */
    @Test(timeout = 1000)  // Esto permite establecer un límite de tiempo de 1 segundo
    public void testWithTimeout() throws InterruptedException {
        final int factorialOf = 1 + (int) (30000 * Math.random());
        System.out.println("Calculando " + factorialOf + '!');

        Thread testThread = new Thread(() -> {
            System.out.println(factorialOf + "! = " + Utils.computeFactorial(factorialOf));
        });

        testThread.start();

        // Usamos join() para esperar hasta que el hilo termine o se agote el tiempo
        testThread.join(1000);  // Esperamos solo 1 segundo

        // Comprobamos si el hilo sigue vivo después de la espera
        if (testThread.isAlive()) {
            testThread.interrupt();
            fail("La prueba tardó demasiado en completarse.");
        }
    }
}
