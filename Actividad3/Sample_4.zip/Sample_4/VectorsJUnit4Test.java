import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import sample.Vectors;

/**
 * Clase de prueba para Vectors.java usando JUnit 4.
 */
public class VectorsJUnit4Test { // Cambié el nombre a JUnit4Test

    @BeforeClass
    public static void setUpClass() {
        System.out.println("Configurando la clase de pruebas...");
    }

    @AfterClass
    public static void tearDownClass() {
        System.out.println("Finalizando la clase de pruebas...");
    }

    /**
     * Prueba del método equal de la clase Vectors.
     */
    @Test
    public void testEqual() {
        System.out.println("* VectorsJUnit4Test: testEqual()");

        assertTrue(Vectors.equal(new int[] {}, new int[] {}));
        assertTrue(Vectors.equal(new int[] {0}, new int[] {0}));
        assertTrue(Vectors.equal(new int[] {0, 0}, new int[] {0, 0}));
        assertTrue(Vectors.equal(new int[] {0, 0, 0}, new int[] {0, 0, 0}));
        assertTrue(Vectors.equal(new int[] {5, 6, 7}, new int[] {5, 6, 7}));

        assertFalse(Vectors.equal(new int[] {}, new int[] {0}));
        assertFalse(Vectors.equal(new int[] {0}, new int[] {0, 0}));
        assertFalse(Vectors.equal(new int[] {0, 0}, new int[] {0, 0, 0}));
        assertFalse(Vectors.equal(new int[] {0, 0, 0}, new int[] {0, 0}));
        assertFalse(Vectors.equal(new int[] {0, 0}, new int[] {0}));
        assertFalse(Vectors.equal(new int[] {0}, new int[] {}));
        assertFalse(Vectors.equal(new int[] {0, 0, 0}, new int[] {0, 0, 1}));
        assertFalse(Vectors.equal(new int[] {0, 0, 0}, new int[] {0, 1, 0}));
        assertFalse(Vectors.equal(new int[] {0, 0, 0}, new int[] {1, 0, 0}));
        assertFalse(Vectors.equal(new int[] {0, 0, 1}, new int[] {0, 0, 3}));
    }

    /**
     * Prueba del método scalarMultiplication de la clase Vectors.
     */
    @Test
    public void testScalarMultiplication() {
        System.out.println("* VectorsJUnit4Test: testScalarMultiplication()");

        assertEquals(0, Vectors.scalarMultiplication(new int[] {0, 0}, new int[] {0, 0}));
        assertEquals(39, Vectors.scalarMultiplication(new int[] {3, 4}, new int[] {5, 6}));
        assertEquals(-39, Vectors.scalarMultiplication(new int[] {-3, 4}, new int[] {5, -6}));
        assertEquals(0, Vectors.scalarMultiplication(new int[] {5, 9}, new int[] {-9, 5}));
        assertEquals(100, Vectors.scalarMultiplication(new int[] {6, 8}, new int[] {6, 8}));
    }
}
