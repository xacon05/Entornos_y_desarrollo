/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.adriansanchez_ej2_ej.exud4;

/**
 *
 * @author 1DAW2425-13
 */
public class AdrianSanchez_Ej2_EjExUD4 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
